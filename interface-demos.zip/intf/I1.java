package com.cdac.intf;

public interface I1 {

    public default void m1(){
        System.out.println("m1() of I1");
    }

}
