package com.cdac.intf;

import java.util.Arrays;

public class TestBookManager {
    public static void main(String[] args) {
        BookManager mgr = new BookManagerImpl();
        Book b1 = mgr.getBook(3);
        b1.displayBookDetails();



        Book[] arr = mgr.getAllBooks();
        System.out.println(Arrays.toString(arr));
    }
}
