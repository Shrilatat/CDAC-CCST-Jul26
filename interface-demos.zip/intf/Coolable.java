package com.cdac.intf;

public interface Coolable {
    public void switchAC();
}
