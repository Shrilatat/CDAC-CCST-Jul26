package com.cdac.intf;


public interface Audiable {
    public void playMusic();
}
