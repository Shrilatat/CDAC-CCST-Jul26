package com.cdac.intf;

public class BookManagerImpl implements BookManager{

    Book[] barr = new Book[4];

    public BookManagerImpl() {

        Book b1 = new Book(1,"Java", "Shrilata", 400);
        Book b2 = new Book(2,"JavaScript", "Shrilata", 500);
        Book b3 = new Book(3,"Learning Java", "Tanvi", 450);
        Book b4 = new Book(4,"Ajax", "Nakul", 300);

        barr = new Book[]{b1, b2, b3, b4};
    }

    @Override
    public Book getBook(int bookid) {

        boolean flag=false;
        Book foundbook = null;

        for(Book b : barr){
            if(b.getBookId() == bookid){
                flag=true;
                foundbook = b;
                break;
            }
        }
        if(flag){
            System.out.println("Found book");
            return foundbook;
        }
        else {
            System.out.println("Book with id " + bookid + "  not found");
            return null;
        }
    }

    @Override
    public Book[] getAllBooks() {
        return barr;
    }
}
