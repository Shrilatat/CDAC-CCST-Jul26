package com.cdac.intf;

public interface I2 {

    public default void m1(){
        System.out.println("m1() of I2");
    }

}
