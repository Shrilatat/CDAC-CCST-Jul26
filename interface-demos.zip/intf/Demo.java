package com.cdac.intf;

public class Demo implements I1, I2{

    @Override
    public void m1() {
        I2.super.m1();
    }
}
