package com.cdac.intf;

@FunctionalInterface
public interface Brakeable {
    public void brake();
   
}
