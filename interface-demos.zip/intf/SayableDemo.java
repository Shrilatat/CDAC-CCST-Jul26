package com.cdac.intf;

public class SayableDemo implements  Sayable{
    @Override
    public void say() {
        System.out.println("Hello World!");
    }

    public static void main(String[] args) {
        Sayable s1 = new SayableDemo();
        s1.say();
        s1.sayLouder();
        Sayable.sayLoudest();
    }
}
