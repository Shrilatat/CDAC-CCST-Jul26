package com.cdac.intf;

public interface BookManager {
    public Book getBook(int bookid);

    public Book[] getAllBooks();

    //public Book[] getBookWithPriceGreaterThan(int amount);
}
