package com.cdac.intf;

public interface Sayable {

    public void say();

    public default void sayLouder(){
        System.out.println("Heloooooooo");
    }

    public static void sayLoudest(){
        System.out.println("Helllooooo Worrrrlllddd");
    }
}
