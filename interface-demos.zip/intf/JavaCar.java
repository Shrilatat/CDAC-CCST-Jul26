package com.cdac.intf;

public class JavaCar extends  Accelerator implements Brakeable, Audiable, Coolable{

    public static void main(String[] args) {
        JavaCar car = new JavaCar();
        car.accelerate();
        car.brake();
        car.playMusic();
        car.switchAC();
    }

    @Override
    public void brake() {
        System.out.println("Stopping the car");
    }

    @Override
    public void playMusic() {
        System.out.println("Playing my fave song!");
    }

    @Override
    public void switchAC() {
        System.out.println("Cooling the car!!");
    }
}
