package com.cdac.intf;

public class Accelerator {
    public void accelerate(){
        System.out.println("Accelerating teh car!!");
    }
}
