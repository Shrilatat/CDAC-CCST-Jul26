package com.cdac.exception;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;

public class ExceptionChainingDemo {

	public void setBirthday(String birthDate) throws InvalidBirthdayException {
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		try {
			Date birthday = formatter.parse(birthDate);
			
			LocalDate localDate = birthday.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			LocalDate today = LocalDate.now();
			int years = Period.between(localDate, today).getYears();
			System.out.println("Happy Birthday! You are " + years + " years old!!");
		} catch (ParseException ex) {
			System.out.println("Catching ParseException : " + ex.getMessage());
			throw new InvalidBirthdayException("Date of birth is invalid");
		}
	}

	public static void main(String[] args) {
		ExceptionChainingDemo demo = new ExceptionChainingDemo();
		try {
			demo.setBirthday("15-8-2003");
			demo.setBirthday("Thu Jan 01 22:00:03 IST 1970");
		} catch (InvalidBirthdayException e) {
			System.out.println("Catching InvalidBirthdayException : " + e.getMessage());
			e.printStackTrace();
		}
	}

}
