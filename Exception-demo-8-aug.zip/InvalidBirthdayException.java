package com.cdac.exception;

public class InvalidBirthdayException extends Exception{

	public InvalidBirthdayException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidBirthdayException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidBirthdayException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidBirthdayException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidBirthdayException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
