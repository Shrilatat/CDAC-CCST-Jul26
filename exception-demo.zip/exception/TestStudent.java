package com.cdac.exception;

public class TestStudent {
    public static void main(String[] args) {
        Student stud = new Student();

        stud.setStudId(101);

        try {
            stud.setSname(null);
        } catch (NonullsInSNameException e) {
            System.out.println(e.getMessage());
        }

        System.out.println(stud);
    }
}
