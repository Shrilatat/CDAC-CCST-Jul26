package com.cdac.exception;

public class NonullsInSNameException extends Exception{
    public NonullsInSNameException() {
    }

    public NonullsInSNameException(String message) {
        super(message);
    }

    public NonullsInSNameException(String message, Throwable cause) {
        super(message, cause);
    }

    public NonullsInSNameException(Throwable cause) {
        super(cause);
    }

    public NonullsInSNameException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
