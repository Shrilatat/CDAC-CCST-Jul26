package com.cdac.exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Demo1 {
    public static void main(String[] args) {
        System.out.println("Before try");
        try{
            System.out.println("In try");
            int[] arr = {1,2,3,4,5};
            System.out.println(arr[3]);
            String str = "120";
            int i = Integer.parseInt(str);
            System.out.println(i);
            System.out.println("Last line of try");
        }
        catch(NumberFormatException ne){
            System.out.println("In Catch");
            System.out.println("Error " + ne.getMessage());
        }
        catch (ArrayIndexOutOfBoundsException e){
            System.out.println(e.getMessage());
        }
        finally {
            System.out.println("In Finally");
        }

        System.out.println("After complete try-catch");

    }
}
