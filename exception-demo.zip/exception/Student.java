package com.cdac.exception;

public class Student {
    int studId;
    String sname;

    public String getSname() {
        return sname;
    }

    public void setSname(String sn) throws  NonullsInSNameException{
        if(sn == null)
            throw new NonullsInSNameException("Student name cannot be null");
        else
          this.sname = sn;
    }

    public int getStudId() {
        return studId;
    }

    public void setStudId(int studId) {
        this.studId = studId;
    }

    @Override
    public String toString() {
        return "Student{" +
                "studId=" + studId +
                ", sname='" + sname + '\'' +
                '}';
    }
}
