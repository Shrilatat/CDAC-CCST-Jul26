package com.cdac.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class LisTTraversalDemo {
    public static void main(String[] args) {
        List<String> names = new ArrayList<>();

        names.add("Avinash");
        names.add("Shivam");
        names.add("Prajakt");
        names.add("Shrilata");
        names.add("Divyansh");
        names.add("Roy");
        names.add("Saurabh");

        System.out.println(names);
        /*for(String name : names)
            System.out.println(name);*/

        Iterator<String> it = names.iterator();
        while(it.hasNext()) {
            String s = it.next();
            if(s.startsWith("S"))
                it.remove();
        }

        System.out.println(names);




    }
}
