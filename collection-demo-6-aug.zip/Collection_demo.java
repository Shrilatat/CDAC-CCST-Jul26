package com.cdac.collection;

import java.util.*;
import java.util.function.Consumer;

public class Collection_demo {

    public static void main(String[] args) {
        List<Integer>  list = Arrays.asList(10,20,30,40,50);

        for(int i : list)  //enhanced for loop
            System.out.println("i = " + i);

        Iterator<Integer> it = list.iterator();
        while(it.hasNext()){
            System.out.println("Iterator : " + it.next());
        }

        //JDK 8 - forEach()

        list.forEach(new Consumer<Integer>() {
            @Override
            public void accept(Integer integer) {
                System.out.println("ForEach " + integer);
            }
        });

        list.forEach((item) -> System.out.println("item : " + item));

        list.forEach(System.out:: println);





        List<String>  names = Arrays.asList("aaa", "bbbb", "ccc", "dddd");

        names.forEach(name -> System.out.println(name));

        List<Emp> empList = Arrays.asList(
                new Emp(101,"Samruddhi", 50000),
                new Emp(102,"Deep", 35000),
                new Emp(103,"Diyansh", 40000),
                new Emp(104,"Avinash", 30800)
        );

        empList.sort(new Comparator<Emp>() {
            @Override
            public int compare(Emp o1, Emp o2) {
                return o1.getEmpName().compareTo(o2.getEmpName());
            }
        });

        empList.sort( (a,b) -> a.getEmpName().compareTo(b.getEmpName()));
        /*
        for(Emp e : empList)
            System.out.println(e);

        empList.forEach(emp -> System.out.println(emp));
        */



        List<String> snames = new ArrayList<>();

        snames.add("Avinash");
        snames.add("Shivam");
        snames.add("Prajakt");
        snames.add("Shrilata");
        snames.add("Divyansh");
        snames.add("Roy");
        snames.add("Saurabh");

        snames.forEach(sname -> System.out.println(sname + "   " + sname.length()));




    }
}
