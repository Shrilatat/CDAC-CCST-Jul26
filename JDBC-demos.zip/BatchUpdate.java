package com.cdac.db;

import java.sql.*;

class BatchUpdate {

	public static void main(String args[]) throws SQLException {
		String url = "jdbc:mysql://localhost:3306/trgdb";

		DriverManager.registerDriver (new com.mysql.cj.jdbc.Driver());
		Connection conn = 
				DriverManager.getConnection (
				url, "root", "root123");
		
        conn.setAutoCommit(false);

		Statement stmt =conn.createStatement();
		stmt.addBatch("insert into dept values(1,'AAA','AAA')");
		stmt.addBatch("insert into dept values(2,'BBB','BBB')");
		stmt.addBatch("insert into dept values(3,'CCC','CCC')");
		stmt.addBatch("insert into dept values(4,'DDD','DDD')");
	    int counts[] = stmt.executeBatch();
	    for(int i : counts) 
	    	System.out.println(i>=1?"Recored inserted successfully":"no!");
		conn.commit();

	}
}
