package com.cdac.db;

import java.sql.*;

public class DbDemo2 {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/trgdb";
        String sql = "delete from dept where deptno = 80";
        //String sql = "insert into dept values(80,'aaa', 'bbbb')";

        try {
            //step-0: Bring driver into build path
            //step-1: Load/register the driver
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            //Class.forName(diver)

            //step-2 : Obtain a connection to DB
            Connection conn = DriverManager.getConnection(url, "root", "root123");

            //step-3 : Create a statement
            Statement stmt = conn.createStatement();

            //step-4 : Craete a resultset
            int i = stmt.executeUpdate(sql);  //DML
            if (i > 0)
                System.out.println("Successfully deleted");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }
}
