package com.cdac.db;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;

public class DeptDaoPS implements DeptDaoIntf {

    Connection conn = null;

    public DeptDaoPS() {
        conn = DBUtils.getConnection();
    }

    @Override
    public void addDept(Dept dept) {
        //String sql = "insert into dept values (" + dept.getDeptno() + ", '" + dept.getDname() + "','" + dept.getLoc() + "')";
        String sql = "insert into dept values(?,?,?)";

        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, dept.getDeptno());
            ps.setString(2, dept.getDname());
            ps.setString(3, dept.getLoc());

            int i = ps.executeUpdate();
            if (i > 0)
                System.out.println("Successfullt added!");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delDept(int id) {
        String sql = "delete from dept where deptno = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1,id);

           ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error in getDeptById: " + e.getMessage());
        }
    }

    @Override
    public List<Dept> getAllDepts() {
        String sql = "select * from dept";
        List<Dept> dlist = new LinkedList<>();

        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                Dept d = new Dept(rs.getInt(1), rs.getString(2), rs.getString(3));
                dlist.add(d);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return dlist;
    }

    @Override
    public Dept getDeptById(int id) {

        Dept d = null;
        String sql = "select * from dept where deptno = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1,id);

            ResultSet rs = ps.executeQuery();
            if (rs.next())
                d = new Dept(rs.getInt(1), rs.getString(2), rs.getString(3));
        } catch (SQLException e) {
            System.out.println("Error in getDeptById: " + e.getMessage());
        }
        return d;
    }

    public static void main(String[] args) {
        DeptDaoPS dao = new DeptDaoPS();
        Dept d = dao.getDeptById(30);
        System.out.println(d);
        Dept newDept = new Dept(75, "Insurance", "Mysore");
         dao.addDept(newDept);
        //dao.delDept(90);
        //List<Dept> list = dao.getAllDepts();
        //for(Dept dept : list)
           // System.out.println(dept);
    }
}
