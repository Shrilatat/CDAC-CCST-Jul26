package com.cdac.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtils {
    //simply gives conn obj
    static Connection conn = null;
    static String url = "jdbc:mysql://localhost:3306/trgdb";

    public static Connection getConnection(){
        if(conn == null){
            try {
                DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
                conn = DriverManager.getConnection(url, "root", "root123");

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        return conn;
    }

    public static void closeConnection(){
        try {
            conn.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
