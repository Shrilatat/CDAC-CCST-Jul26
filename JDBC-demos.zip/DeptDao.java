package com.cdac.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

public class DeptDao implements DeptDaoIntf {

    Connection conn = null;

    public DeptDao() {
        conn = DBUtils.getConnection();
    }

    @Override
    public void addDept(Dept dept) {
        String sql = "insert into dept values (" + dept.getDeptno() + ", '" + dept.getDname() + "','" + dept.getLoc() + "')";
        try {
            Statement  stmt = conn.createStatement();
            int i = stmt.executeUpdate(sql);
            if (i > 0)
                System.out.println("Successfullt added!");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delDept(int id) {
        String sql = "delete from dept where deptno = " + id;
        try {
            Statement  stmt = conn.createStatement();
            int i = stmt.executeUpdate(sql);
            if (i > 0)
                System.out.println("Successfullt deleted!");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Dept> getAllDepts() {
        String sql = "select * from dept";
        List<Dept> dlist = new LinkedList<>();

        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                Dept d = new Dept(rs.getInt(1), rs.getString(2), rs.getString(3));
                dlist.add(d);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return dlist;
    }

    @Override
    public Dept getDeptById(int id) {

        Dept d = null;
        String sql = "select * from dept where deptno = " + id;
        System.out.println(sql);
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next())
                d = new Dept(rs.getInt(1), rs.getString(2), rs.getString(3));
        } catch (SQLException e) {
            System.out.println("Error in getDeptById: " + e.getMessage());
        }
        return d;
    }

    public static void main(String[] args) {
        DeptDao dao = new DeptDao();
        Dept d = dao.getDeptById(90);
        System.out.println(d);
        //Dept newDept = new Dept(90, "Insurance", "Mysore");
       // dao.addDept(newDept);
        //dao.delDept(90);
        List<Dept> list = dao.getAllDepts();
        for(Dept dept : list)
            System.out.println(dept);
    }
}
