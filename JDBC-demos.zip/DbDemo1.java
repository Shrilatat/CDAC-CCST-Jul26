package com.cdac.db;

import java.sql.*;

public class DbDemo1 {
    public static void main(String[] args) {
        String sql = "select * from dept";
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            while(rs.next())
               System.out.println(rs.getInt(1) + " : " + rs.getString(2) + " : " + rs.getString(3));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        finally {
            try{
                if(rs != null)
                    rs.close();
                if(stmt != null)
                    stmt.close();
                if(conn != null)
                    conn.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
