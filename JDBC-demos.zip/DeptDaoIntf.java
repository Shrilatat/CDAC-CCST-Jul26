package com.cdac.db;

import java.util.List;

public interface DeptDaoIntf {
    public void addDept(Dept dept);
    public void delDept(int id);

    public List<Dept> getAllDepts();

    public Dept getDeptById(int id);

}
