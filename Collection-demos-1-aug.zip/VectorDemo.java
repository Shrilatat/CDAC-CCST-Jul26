package com.cdac.collection;

import com.cdac.funda.Box;
import com.cdac.intf.Book;

import java.util.Stack;
import java.util.Vector;

public class VectorDemo {
    public static void main(String[] args) {
        Vector v = new Vector();
        System.out.println(v.capacity());
        System.out.println(v.size());
        System.out.println("------------");

        v.add(100);
        v.add("Hello");
        v.add(new Box(1,2,3));
        v.add(new Book(1,"aaa", "bbb", 300));

        System.out.println(v.capacity());
        System.out.println(v.size());
        System.out.println("------------");

        v.add(100);
        v.add("Hello");
        v.add(new Box(1,2,3));
        v.add(new Book(1,"aaa", "bbb", 300));
        v.add(1);
        v.add(true);

        v.add("aaa");
        System.out.println(v.capacity());
        System.out.println(v.size());
        System.out.println("------------");

        v.trimToSize();

        System.out.println(v.capacity());
        System.out.println(v.size());
        System.out.println("------------");


        Stack s = new Stack();
        s.push(100);
        s.push(200);
        s.push(300);

        System.out.println(s);
        s.pop();
        System.out.println(s);


    }
}
