import java.util.Scanner;

public class HelloWorld {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your age");
        int age = sc.nextInt();
        System.out.println("Enter your Name");
        String sname = sc.next();
        System.out.println("Age is : " + age +  "  name is : " + sname);
    }
}
