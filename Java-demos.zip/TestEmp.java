public class TestEmp {
    public static void main(String[] args) {
        Emp e1 = new Emp(1, "aaa");
        Emp e2 = new WageEmp(2, "bbb", 1000, 10);
        Emp e3 = new SalesEmp(3, "ccc", 1000, 10, 2000);

        Emp[] emparr = {e1, e2, e3};

        for (Emp e : emparr) {
            if(e instanceof SalesEmp){
                SalesEmp se = (SalesEmp) e;
                System.out.println("Salary of SalesEmp: " + se.calculateSalary());
            } else if(e instanceof WageEmp){
                WageEmp we = (WageEmp) e;
                System.out.println("Salary of WageEmp: " + we.calculateSalary());
            } else {
                System.out.println("Salary of Emp: N/A");
            }
        }

    }
}
