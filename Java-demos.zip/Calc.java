//Method Overloading  --> Static Polymorphism

public class Calc {
    public int add(int a, int b){
        return a + b;
    }

    public String add(String a, String b){
        return a + b;
    }

    public int add(int a, int b, int c){
        return a + b + c;
    }

    public static void main(String[] args) {
        Calc calc = new Calc();
        System.out.println(calc.add(10,20));
        System.out.println(calc.add("aaa", "bbb"));
        System.out.println(calc.add(1,2,3));

    }
}
