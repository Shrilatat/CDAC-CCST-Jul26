public class Box {
    private int length, width, height;

    public Box() {
    }
    public Box(int length, int width, int height) {
        this.length = length;
        this.width = width;
        this.height = height;
    }

    @Override
    public String toString() {
        return "Box{" +
                "length=" + length +
                ", width=" + width +
                ", height=" + height +
                '}';
    }

    public int calcVolume(){
        int volume =  length * width * height;
        return volume;
    }
}
