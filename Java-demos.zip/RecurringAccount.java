public class RecurringAccount extends Account{
    double amount;
    double monthly_amount;

    public RecurringAccount(int acctId, String cname, double amount, double monthly_amount) {
        super(acctId, cname);
        this.amount = amount;
        this.monthly_amount = monthly_amount;
    }

    public void displayAcctDetails() {
        super.displayAcctDetails();
        System.out.println( "RA Balance Amount ='" + amount);
    }
}
