public class TestAccount {
    public static void main(String[] args) {
        Account a1 = new Account(101, "aaaa");
        Account a2 = new SavingsAccount(102, "bbb", 50000, 7.25);
        Account a3 = new RecurringAccount(103, "cccc", 40000, 5000);

        a2.displayAcctDetails();
        a3.displayAcctDetails();
    }
}
