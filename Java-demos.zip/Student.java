public class Student {
    private int studId;
    private String sname;
    private int age;
    private Address address;
    private ContactDetails contactDetails;

    public Student(int studId, String sname, int age, Address address, ContactDetails contactDetails) {
        this.studId = studId;
        this.sname = sname;
        this.age = age;
        this.address = address;
        this.contactDetails = contactDetails;
    }

    @Override
    public String toString() {
        return "Student{" +
                "studId=" + studId +
                ", sname='" + sname + '\'' +
                ", age=" + age +
                ", address=" + address +
                ", contactDetails=" + contactDetails +
                '}';
    }

    public static void main(String[] args) {
        Address a1 = new Address("123", "New York", "NY");
        ContactDetails cd = new ContactDetails("1234567890", "abc@gmail.com");
        Student s1 = new Student(101, "aaa", 22, a1, cd);

        System.out.println(s1);
    }
}
