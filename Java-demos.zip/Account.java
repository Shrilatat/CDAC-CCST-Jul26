public class Account {
    int acctId;
   String cname;

    public Account() {
    }

    public Account(int acctId, String cname) {
        this.acctId = acctId;
        this.cname = cname;
    }

    public void displayAcctDetails() {
        System.out.println( "Account{acctId=" + acctId + ", cname='" + cname + "}");
    }
}
