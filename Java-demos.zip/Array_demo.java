public class Array_demo {
    public static void main(String[] args) {
        /*
        int marks[] = new int[5];
        marks[0] = 89;
        marks[1] = 70;
        marks[2] = 60;
        marks[3] = 50;
        marks[4] = 78;

        //enhanced for loop
        for(int mark: marks)
            System.out.println(mark);


        int[] nos = {11,22,33,44,55};

        for(int num : nos)
            System.out.println(num);

        float temp[] = {22.3f, 55.4f, 11.0f, 33.5f};

        for(float t : temp)
            System.out.println(t);

        char carr[] = {'a', '/','$',' ', '9'};

        for(char ch : carr)
            System.out.println(ch);

        String names[] = {"Prajakta", "Tanvi", "Parag", "Soha"};

        for(String name : names)
            System.out.println(name);

   */
        int arr[][] = {{1,2}, {3,4,5}, {7,8}};
        for(int i = 0 ; i < arr.length ; i++){
            for(int j = 0; j < arr[i].length; j++)
                System.out.print(arr[i][j] + "  ");
            System.out.println("\n");
        }

        int[] num_arr = {23, 45, 25, 2, 8};

        for(int i = 0 ; i < num_arr.length ; i++)
            System.out.println(num_arr[i] * num_arr[i]);

        //for(int no : num_arr)
           // System.out.println(no * no);

    }
}
