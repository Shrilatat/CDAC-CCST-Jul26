public class Array_Demo1 {

    public int f1(int[] arr){
        //code to sum
        int sum = 0;
        for(int num : arr){
            sum += num;
        }
        return sum;
    }

    public int[] f2(int[] arr){

        return arr;
    }


    public static void main(String[] args) {
        int[] nums = {1,2,3,4,5};
        Array_Demo1 demo = new Array_Demo1();
        demo.f1(nums);
    }
}
