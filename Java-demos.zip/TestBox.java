public class TestBox {
    public static void main(String[] args) {

        Box b1 = new Box(1,2,3);
        Box b2 = new Box(10,2,30);
        Box b3 = new Box(11,5,6);

        Box[] boxes = {b1, b2, b3};

/*
        Box[] boxes = new Box[3];
        boxes[0] = new Box(1,2,3);
        boxes[1] = new Box(10,2,30);
        boxes[2] = new Box(11,5,6);
        */
        for(Box b : boxes)
            System.out.println(b);


    }
}
