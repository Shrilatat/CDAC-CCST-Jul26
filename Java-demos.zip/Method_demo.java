public class Method_demo {

    public void greet(){
        System.out.println("Hello User!!");
    }

    public void greetUser(String fname, String lname){
        System.out.println("Hello " + fname + "," + lname + "!!");
    }

    public int add(int a, int b){
        return a + b;
    }

    public boolean isValidCard(int cardno, String name){
        //code
        if(true)
            return true;
        else return false;
    }


    public String concatString(String str1, String str2){
        return str1 + str2;
    }




    public static void main(String[] args) {
        Method_demo demo = new Method_demo();
        demo.greet();  //invoking/calling
        demo.greetUser("Tanvi", "Rokade");
        System.out.println(demo.add(10,20));

    }
}
