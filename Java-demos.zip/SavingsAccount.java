public class SavingsAccount extends Account{
    double bal;
    double roi;

    public SavingsAccount(int acctId, String cname, double bal, double roi) {
        super(acctId, cname);
        this.bal = bal;
        this.roi = roi;
    }

    @Override
    public void displayAcctDetails() {
        super.displayAcctDetails();
        System.out.println( "SA Balance ='" + bal);
    }

    public static void main(String[] args) {
        Account sa1 = new SavingsAccount(101, "Tanvi", 50000, 7.5);
        sa1.displayAcctDetails();
    }
}
