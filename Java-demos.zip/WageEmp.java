public class WageEmp extends Emp{
    private int rate, hrs;

    public WageEmp(){
        super();
    }

    public WageEmp(int empId, String empName, int rate, int hrs) {
        super(empId, empName);
        this.rate = rate;
        this.hrs = hrs;
    }

    public int calculateSalary(){
        return  rate * hrs;
    }

    @Override
    public void displayEmpDetails() {
        super.displayEmpDetails();
        System.out.println("WageEmp{" +
                "rate=" + rate +
                ", hrs=" + hrs +
                '}');
    }

    public static void main(String[] args) {
        WageEmp we1 = new WageEmp(101,"Prajakt", 1000, 20);
        we1.displayEmpDetails();
        System.out.println(we1.calculateSalary());
    }
}
