public class SalesEmp extends WageEmp{
   private int comm;

    public SalesEmp(int empId, String empName, int rate, int hrs, int comm) {
        super(empId, empName, rate, hrs);
        this.comm = comm;
    }

    @Override
    public int calculateSalary(){
        return super.calculateSalary() + comm;
    }

    @Override
    public void displayEmpDetails() {
        super.displayEmpDetails();
        System.out.println("SalesEmp{" +
                "comm=" + comm +
                '}');
    }

    public static void main(String[] args) {
        SalesEmp se1 = new SalesEmp(1001, "Ashwini", 1000, 10, 2000);
        System.out.println(se1.calculateSalary());
        se1.displayEmpDetails();

        WageEmp we1 = new WageEmp();
        we1.calculateSalary();
    }
}
