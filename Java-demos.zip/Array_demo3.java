public class Array_demo3 {

    public static void main(String[] args) {
        Array_demo3 demo = new Array_demo3();
        int arr[] = {45, 34, 89, 36, 23, 77};


    }
}
