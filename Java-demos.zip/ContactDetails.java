public class ContactDetails {
    private String phno, email;

    public ContactDetails(String phno, String email) {
        this.phno = phno;
        this.email = email;
    }

    @Override
    public String toString() {
        return "ContactDetails{" +
                "phno='" + phno + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}
