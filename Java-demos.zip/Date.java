public class Date {
    private int dd, mm, yy;

    public int getDd() {
        return dd;
    }

    public void setDd(int dd) {
        if(dd < 1 || dd > 31)
            System.out.println("Invalid Date!!");
        this.dd = dd;
    }

    public int getMm() {
        return mm;
    }

    public void setMm(int mm) {
        if(mm < 1 || mm > 12)
            System.out.println("Invalid month!!");
        this.mm = mm;
    }

    public int getYy() {
        return yy;
    }

    public void setYy(int yy) {
        this.yy = yy;
    }

    @Override
    public String toString() {
        return "Date{" +
                "dd=" + dd +
                ", mm=" + mm +
                ", yy=" + yy +
                '}';
    }

    public static void main(String[] args) {
        Date d1 = new Date();
        d1.setDd(35);
        d1.setMm(15);
        d1.setYy(2026);
        System.out.println(d1);
    }
}
