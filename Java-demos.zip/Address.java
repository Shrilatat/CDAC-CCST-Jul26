public class Address {
    private String flatno, city, state;

    public Address(String flatno, String city, String state) {
        this.flatno = flatno;
        this.city = city;
        this.state = state;
    }

    @Override
    public String toString() {
        return "Address{" +
                "flatno='" + flatno + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                '}';
    }
}
