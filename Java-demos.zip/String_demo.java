import java.util.Arrays;

public class String_demo {

    public static void main(String[] args) {
        String s1 = "Hello World";
        String s2 = new String("Hello World");

        System.out.println(s1.length());  //11
        System.out.println(s1.indexOf('o')); //4
        System.out.println(s1.indexOf("orl")); //7
        System.out.println(s1.charAt(8)); //r
        System.out.println(s1.toUpperCase()); //HELLO WORLD
        System.out.println(s1.toLowerCase()); //hello world
        System.out.println(s1.equals(s2));  //true
        System.out.println(s1 == s2); //false

        String s3 = "Tanvi#Raj#Samu#Supriya";
        String[] names = s3.split("#");

        System.out.println(Arrays.toString(names)); // [Tanvi, Raj, Samu, Supriya]


        StringBuilder sb = new StringBuilder("Hello");
        sb.append(" World");
        System.out.println(sb.toString());
        sb.delete(5, 11);
        System.out.println(sb.toString());

    }
}