public class StaticBlockDemo {

    static{
        System.out.println("In static block - 1 ");
    }

    static{
        for(int i = 0; i < 5 ; i++)
        System.out.println("In static block - 2 " + i);
    }

    static{
        System.out.println("In static block - 3 ");
    }

    static{
        System.out.println("In static block - 4 ");
    }


    public static void main(String[] args) {
        StaticBlockDemo demo = new StaticBlockDemo();
    }
}
