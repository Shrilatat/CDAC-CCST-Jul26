public class StaticDemo {

    int i = 10;
    static int j = 20;

    public void m1(){
        System.out.println("in m1()" + i + "  " + j);
    }

    public static void m2(){
        System.out.println("in m2()"  + j);
    }

    public static void main(String[] params) {
        StaticDemo demo = new StaticDemo();
        demo.m1();
        m2();
    }

}
