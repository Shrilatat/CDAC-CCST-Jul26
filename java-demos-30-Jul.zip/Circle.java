public class Circle extends Point{

    public void draw(){
        System.out.println("Drawing a Circle!!");
    }

    public static void main(String[] args) {
        Shape s1 = new Point();
        Shape s2 = new Circle();
    }
}
