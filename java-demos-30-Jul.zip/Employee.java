public class Employee {
    int id=1;
    String ename;
    double sal;
    static int counter = 1;

    public Employee() {
        this.id = counter++;
        this.ename = "Unknown";
    }

    public Employee(String ename) {
        this.id = counter++;
        this.ename = ename;
    }

    public Employee(String ename, double sal) {
        this.id = counter++;
        this.ename = ename;
        this.sal = sal;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", ename='" + ename + '\'' +
                ", sal=" + sal +
                '}';
    }

    public static void main(String[] args) {
        Employee e1 = new Employee();
        Employee e2 = new Employee("Prajakt");
        Employee e3 = new Employee("Tanvi", 45000);
        System.out.println(e1);
        System.out.println(e2);
        System.out.println(e3);

    }
}
