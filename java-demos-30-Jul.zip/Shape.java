public abstract class Shape {
    private String color;

    public String getColor() {  //concrete methods
        return color;
    }

    public void setColor(String color) { //concrete methods
        this.color = color;
    }

    public abstract void draw(); //abstract method

    public Shape() {
        System.out.println("In Shape cons");
    }
}
