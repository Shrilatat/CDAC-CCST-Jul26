public class  Point extends  Shape{

    public void draw(){
        System.out.println("Drawing a point!!");
    }

    public static void main(String[] args) {
        Shape p1 = new Point();
        p1.draw();
        p1.setColor("blue");
        System.out.println(p1.getColor());
    }

}
