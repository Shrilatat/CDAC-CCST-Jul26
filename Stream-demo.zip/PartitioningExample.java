package com.trg.Streams;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class PartitioningExample {
    public static void main(String[] args) {
        List<Integer> numbers = IntStream.rangeClosed(1, 20)
        		.boxed()
        		.collect(Collectors.toList());

        // Partition numbers into even and odd
        Map<Boolean, List<Integer>> partitionedByEvenOdd = 
            numbers.stream()
                   .collect(Collectors.partitioningBy(n -> n % 2 == 0));

        System.out.println("Even Numbers: " + partitionedByEvenOdd.get(true));
        System.out.println("Odd Numbers: " + partitionedByEvenOdd.get(false));
        
        //--------------------- Example 2 ------------------
        
        List<Employee> employees = Arrays.asList(
                new Employee("Manish", "acct-1",25000),
                new Employee("Girish", "acct-2", 35000),
                new Employee("Satish", "acct-2", 28000),
                new Employee("Vineesh", "acct-3", 42000),
                new Employee("Nitish", "acct-3", 22000),
                new Employee("Dinesh", "acct-1", 30000)
            );

            // Partition employees based on age
            Map<Boolean, List<Employee>> partitionedBySal = employees.stream()
                     .collect(Collectors.partitioningBy(e -> e.getSalary() >= 30000));
            
            List<Employee> lowSalEmps = partitionedBySal.get(true);
            for(Employee e : lowSalEmps)
            	System.out.println(e);

            System.out.println("----------------------------------------");
            
            List<Employee> highSalEmps = partitionedBySal.get(false);
            for(Employee e : highSalEmps)
            	System.out.println(e);
            
    }
}

//System.out.println("Employees with sal 30000 and above: " + partitionedBySal.get(true));
//System.out.println("Employees below 30000: " + partitionedBySal.get(false));