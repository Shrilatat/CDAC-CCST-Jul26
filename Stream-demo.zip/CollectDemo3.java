package com.trg.Streams;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class CollectDemo3 {
	public static void main(String[] args) {
		List<String> names = Arrays.asList("Joy","Yash","Anita","Sunita","Ria","Nia","Arti");
		Map<Integer, List<String>> groupedByLength = names.stream()
				.collect(Collectors.groupingBy(String::length));
		
		System.out.println(groupedByLength);
		
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6);
		Map<Boolean, List<Integer>> groupedByOddEven = numbers.stream()
		    .collect(Collectors.groupingBy(num -> num % 2 == 0));

		System.out.println(groupedByOddEven);
	}

}
