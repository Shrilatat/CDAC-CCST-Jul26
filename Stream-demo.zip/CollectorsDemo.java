package com.trg.Streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

class Person {
	private Integer id;
	private String name;

	public Person(Integer id, String name) {
		this.id = id;
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + "]";
	}
	
}

public class CollectorsDemo {
	public static void main(String[] args) {
		List<String> strlist = Arrays.asList("Abc", "Joy", "Xyz", "Jamie");
		List<String> strListWithJ = 
				strlist.stream()
				.filter(s -> s.startsWith("J"))
				.collect(Collectors.toList());
		System.out.println(strListWithJ);

		List<Person> list = new ArrayList<>();
		list.add(new Person(100, "Mohan"));
		list.add(new Person(200, "Sohan"));
		list.add(new Person(300, "Mahesh"));
		
		List<String> names = list.stream()
				                 .map(Person::getName)
				                 .collect(Collectors.toList());
		
		System.out.println(names);  //[Mohan, Sohan, Mahesh]
		
		
		List<Integer> number = Arrays.asList(2,3,4,5);
	    List<Integer> square = number
	    		               .stream()
	    		               .map(x -> x*x)
	    		               .collect(Collectors.toList());
	    System.out.println(square);   //[4, 9, 16, 25]
	    
	    Set<Integer> squareSet = number
	    		                 .stream()
	    		                 .map(x->x*x)
	    		                 .collect(Collectors.toSet());
	    System.out.println(squareSet);
	    
	    //The sorted method is used to sort the stream.
	    
	    List<String> unames = Arrays.asList("Kavita","Anita","Sunita", "Binita");
	    List result = unames
	    		      .stream()
	    		      .sorted()
	    		      .collect(Collectors.toList());
	    System.out.println(result);  //[Anita, Binita, Kavita, Sunita]
	    
	    /*Integer[] empIds = { 1, 2, 3, 4 };
	    
	    Employee employee = Stream.of(empIds)
	      .map(employeeDao::findById)
	      .filter(e -> e != null)
	      .filter(e -> e.getSalary() > 100000)
	      .findFirst()
	      .orElse(null);*/
	    
	    Person[] persons = list
	    		           .stream()
	    		           .toArray(Person[]::new);
	    System.out.println(Arrays.toString(persons));
	}
}
