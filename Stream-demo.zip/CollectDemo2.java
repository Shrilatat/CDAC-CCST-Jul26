package com.trg.Streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CollectDemo2 {
	
	public static long count(List<String> strList) {
		return strList.stream()
				.collect(Collectors.counting());
	}
	
	public static void main(String[] args) {
		List<String> strList = Arrays.asList("Joy","Roy","Nia", "Yash");
		System.out.println(count(strList));  //4
	}

}
