package com.trg.Streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CollectDemo1 {
	
	public static String getString(List<Integer> numList) {
	    return numList.stream()
	    		.map(no -> no%2 ==0 ? "e-" + no : "o-" + no )
	    		.collect(Collectors.joining(","));
	}
	
	public static void main(String[] args) {
		List<Integer> nos = Arrays.asList(6,3,10,34,67);
		System.out.println(getString(nos));
	}
}
