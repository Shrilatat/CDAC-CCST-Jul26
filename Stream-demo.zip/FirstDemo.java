package com.trg.Streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

// code reads a list of integers and computes the sum of the squares of
// all odd integers in the list.
public class FirstDemo {
	public static void main(String[] args) {
		List<Integer> nosList = Arrays.asList(1, 2, 3, 4, 5);
		
		// Get the stream from the list
		Stream<Integer> nosStream = nosList.stream();
		
		// Get a stream of odd integers
		Stream<Integer> oddNosStream = nosStream.filter(n -> n % 2 == 1);
		// Get a stream of the squares of odd integers
		Stream<Integer> sqNosStream = oddNosStream.map(n -> n * n);
		// Sum all integers in the stream
		int sum = sqNosStream.reduce(0, (n1, n2) -> n1 + n2);

		
		 /* The Integer class contains a static sum() method to perform sum of
		 * two integers. You can rewrite the code using a method reference: */
		int sum1 = sqNosStream.reduce(0, Integer::sum);
		System.out.println("The sum is : " + sum);
	}
}
