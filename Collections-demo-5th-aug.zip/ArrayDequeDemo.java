package com.cdac.collection;

import java.util.*;

public class ArrayDequeDemo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ArrayDeque<String> dqname = new ArrayDeque<String>();
		String name = null;
		System.out.println("Enter any String: ");
		name = sc.next();
		dqname.add(name);
		show(dqname);

		System.out.println("Enter any string to add on starting point of deque by addFirst():");
		name = sc.next();
		dqname.addFirst(name);
		show(dqname);
		System.out.println("Enter any string to add on ending point of deque by addLast():");
		name = sc.next();
		dqname.addLast(name);
		show(dqname);
		System.out.println("Enter any string to add on starting point of deque by offerfirst() :");
		name = sc.next();
		dqname.offerFirst(name);
		show(dqname);
		System.out.println("Enter any string to add on ending point of deque by offerlast() :");
		name = sc.next();
		dqname.offerLast(name);
		show(dqname);
		System.out.println("Getting the first element by using getFirst()");
		String str1 = dqname.getFirst();
		System.out.println("First element is  : " + str1);
		System.out.println("Getting the Last element by using getLast()");
		str1 = dqname.getLast();
		System.out.println("Last element is  : " + str1);

		System.out.println("Getting the first element by using peekFirst()");
		str1 = dqname.peekFirst();
		System.out.println("First element is  : " + str1);

		System.out.println("Getting the Last element by using peekLast()");
		str1 = dqname.peekLast();
		System.out.println("Last element is  : " + str1);
		System.out.println("Removing the first element by using removeFirst()");
		str1 = dqname.removeFirst();
		show(dqname);
		System.out.println("Removing the Last element by using removeLast()");
		str1 = dqname.removeLast();
		show(dqname);
		System.out.println("Removing the first element by using pollFirst()");
		str1 = dqname.pollFirst();
		show(dqname);
		System.out.println("Removing the Last element by using pollFirst()");
		str1 = dqname.pollLast();
		show(dqname);
	}

	static void show(ArrayDeque<String> dqname) {
		Iterator<String> nameIter = dqname.iterator();
		while (nameIter.hasNext())
			System.out.println(nameIter.next());
	}

}
