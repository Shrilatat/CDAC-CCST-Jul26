package com.cdac.collection;

import java.util.Comparator;

public class BookComparatorByBookName implements Comparator<Book> {
    @Override
    public int compare(Book o1, Book o2) {
        return o1.getBname().compareTo(o2.getBname());
    }
}
