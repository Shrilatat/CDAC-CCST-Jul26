package com.cdac.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

//generics  Java 5

public class ListDemo {
    public static void main(String[] args) {
        List<String> names = new ArrayList<>();

        names.add("Avinash");
        names.add("Prajakt");
        names.add("Divyansh");
        names.add("Roy");

        Collections.sort(names);
        System.out.println(names);


        //JDK 1.5 enhanced for loop
        for (String name : names)
            System.out.println(name + "  " + name.length());


        List<Integer> nums = new ArrayList<>();
        nums.add(10);
        nums.add(20);
        nums.add(30);
        nums.add(10);

        for (int no : nums)
            System.out.println(no * no);

        List<Float> temps = new ArrayList<>();
        temps.add(23.4f);
        temps.add(24.4f);
        temps.add(25.0f);
        temps.add(23.7f);

        for (float temp : temps)
            System.out.println(temp);

        List<Book> books = new ArrayList<>();
        books.add(new Book(101, "Java", "Cay H", 450));
        books.add(new Book(101, "Java", "Cay H", 450));
        books.add(new Book(101, "Java", "Cay H", 450));
        books.add(new Book(101, "Java", "Cay H", 450));

        Collections.sort(books, new BookComparatorByBookName());

        for(Book b : books)
            b.displayBookDetails();

    }
}
