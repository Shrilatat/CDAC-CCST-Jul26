package com.cdac.collection;

import java.util.Queue;

public class QueueDempoWithAi {
    public static void main(String[] args) {
        //create a priority queue with emp class objects
        Queue<Emp> empQueue = new java.util.PriorityQueue<>();
        empQueue.add(new Emp(101, "Tanvi", 45000));
        empQueue.add(new Emp(102, "Supriya", 55000));
        empQueue.add(new Emp(103, "Zaid", 35000));


    }
}
