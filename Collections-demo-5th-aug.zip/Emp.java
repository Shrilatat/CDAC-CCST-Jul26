package com.cdac.collection;

public class Emp implements Comparable<Emp>{
    int empId;
    String empName;
    double sal;

    public Emp(int empId, String empName, double sal) {
        this.empId = empId;
        this.empName = empName;
        this.sal = sal;
    }

    @Override
    public String toString() {
        return "Emp{" +
                "empId=" + empId +
                ", empName='" + empName + '\'' +
                ", sal=" + sal +
                '}';
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public double getSal() {
        return sal;
    }

    public void setSal(double sal) {
        this.sal = sal;
    }
/*
    @Override
    public int compareTo(Object o) {
        Emp e = (Emp)o;
        return this.getEmpName().compareTo(e.getEmpName());
        //return this.getEmpId() - e.getEmpId();
        /*
        if(this.getEmpId() < e.getEmpId())
            return -1;
        else if(this.getEmpId() > e.getEmpId())
            return 1;
        return 0;
        */


    //}


    @Override
    public int compareTo(Emp o) {
        return this.getEmpName().compareTo(o.getEmpName());
    }
}
