package com.cdac.collection;

import java.util.*;

public class HashSetDemo {
    public static void main(String[] args) {

        Set<Integer> nos = new TreeSet<>();
        nos.add(600);
        nos.add(200);
        nos.add(100);
        nos.add(400);
        nos.add(900);

        Iterator<Integer> it = nos.iterator();
        while(it.hasNext())
            System.out.println(it.next());

        Set<String> names = new TreeSet<>();
        names.add("Avinash");
        names.add("Prajakt");
        names.add("Divyansh");
        names.add("Prajakta");
        names.add("Tanvi");

        System.out.println(names);

        Set<Emp> emps = new TreeSet<>();
        emps.add(new Emp(104, "Tanvi", 45000));
        emps.add(new Emp(106, "Zaid", 25000));
        emps.add(new Emp(101, "Ashwini", 35000));
        emps.add(new Emp(103, "Saurabh", 28000));
        emps.add(new Emp(108, "Prajakta", 49000));

       for(Emp e : emps)
           System.out.println(e);

        Set<Book> books = new TreeSet<>(new BookComparatorByBookName());
        books.add(new Book(103, "Java", "nnnn", 450));
        books.add(new Book(101, "Javacript", "dddd", 150));
        books.add(new Book(102, "Python", "aaa", 550));
        books.add(new Book(104, "Ajax", "pppp", 400));

        for(Book b : books)
            System.out.println(b);
    }
}
