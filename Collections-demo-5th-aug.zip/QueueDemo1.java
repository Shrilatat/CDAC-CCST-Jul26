package com.cdac.collection;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueDemo1 {
    public static void main(String[] args) {
        Queue<String> names = new PriorityQueue<>();
        names.add("Prajakt");
        names.add("Divyansh");
        names.add("Avinash");
        names.add("Zaid");
        names.add("Prajakta");
        names.add("Tanvi");
        System.out.println(names);

        /*

        names.add("Supriya");
        names.offer("Ashwini");

        System.out.println(names.peek());
        System.out.println(names.element());

        names.remove();
        names.poll();

        System.out.println(names);
*/

    }
}
