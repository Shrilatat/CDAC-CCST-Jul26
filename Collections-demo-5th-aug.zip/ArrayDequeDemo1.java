package com.trg.collections;

import java.util.ArrayDeque;
import java.util.Deque;

public class ArrayDequeDemo1 {
	public static void main(String[] args) {
        
        Deque<String> deque = new ArrayDeque<>(); // 1. Instantiation

        System.out.println("-- ArrayDeque as a Double-Ended Queue --");
        
        // 2. Adding elements to both ends
        deque.addLast("Middle");   // [Middle]
        deque.addFirst("Front");   // [Front, Middle]
        deque.addLast("Back");     // [Front, Middle, Back]
        System.out.println("Initial Deque: " + deque);

        // 3. Inspecting elements without removing them
        System.out.println("First Element (peek): " + deque.peekFirst());
        System.out.println("Last Element (peek): " + deque.peekLast());

        // 4. Removing elements from both ends
        System.out.println("Remove from Front: " + deque.removeFirst());
        System.out.println("Remove from Back: " + deque.removeLast());
        System.out.println("Deque after removals: " + deque);

        System.out.println("\n--ArrayDeque as a LIFO Stack ---");
        Deque<Integer> stack = new ArrayDeque<>();

        // 5. Push operations
        stack.push(10);
        stack.push(20);
        stack.push(30);
        System.out.println("Stack after pushes: " + stack);

        // 6. Pop operations
        System.out.println("Popped from stack: " + stack.pop());
        System.out.println("Popped from stack: " + stack.pop());
        System.out.println("Final Stack: " + stack);
    }
}




