package com.cdac.collection;

import java.util.*;

public class MapDemo {
    public static void main(String[] args) {
        Map<Integer, String> map = new HashMap<>();
        map.put(1, "Jan");
        map.put(2, "Feb");
        map.put(3, "Mar");
        map.put(4, "Apr");
        map.put(5, "May");

       map.remove(4);
        System.out.println(map);
/*
       Set<Integer> keys = map.keySet();
       for(Integer key : keys){
           System.out.println(key + "  :   " + map.get(key));
       }
       */

        //traverse thru map collection using map.entry
        Set<Map.Entry<Integer, String>> entries = map.entrySet();
        for (Map.Entry<Integer, String> entry : entries) {
            System.out.println(entry.getKey() + "  :   " + entry.getValue());
        }

        Map<String, Emp> emps = new HashMap<>();
        emps.put("Tanvi", new Emp(101,"Tanvi",45000));
        emps.put("Supriya", new Emp(102,"Supriya",55000));
        emps.put("Zaid", new Emp(103,"Zaid",35000));

        Set<String> names = emps.keySet();
        Iterator<String> it = names.iterator();
        while(it.hasNext())
            System.out.println(emps.get(it.next()));




    }
}
